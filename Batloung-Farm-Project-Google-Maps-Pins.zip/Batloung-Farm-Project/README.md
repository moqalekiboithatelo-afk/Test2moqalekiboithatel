# Batloung Farm Distribution Management System

A full-stack fresh-produce distribution management system for Batloung Farm, Maseru, Lesotho. This project is structured to address the DIWA2110 Web Application Development take-home test.

## Technology
- Frontend: React, TypeScript, TanStack Start, Tailwind CSS
- Backend: Node.js, Express 5, mysql2, async/await
- Database: MySQL

## Features and assignment coverage
- Eight core relational tables: suppliers, fruits, vendors, purchases, purchase_details, sales, sales_details and stock; plus a payments table for payment history.
- Packaging-specific stock balances for SMALL, MEDIUM and LARGE boxes.
- Supplier and vendor CRUD; fruit registration and stock/low-stock queries.
- Multi-item purchase transactions automatically calculate totals and increase stock.
- Multi-item sales lock/check stock, calculate totals, create sale details and reduce stock atomically. A failed item rolls back the entire sale.
- Cash, mobile money and credit payment methods; PAID, PARTIALLY_PAID and UNPAID statuses; outstanding vendor balances.
- Reports for top five fruits, revenue by date range and highest-volume vendor.
- Dashboard calls the API when it is available and displays clearly labelled preview figures otherwise.

## Setup
1. Install Node.js 20+ and MySQL 8+.
2. Create the database and tables by running `database/schema.sql` in MySQL Workbench or the MySQL CLI.
3. Copy `.env.example` to `.env` and enter your local MySQL username/password.
4. Install dependencies: `npm install`.
5. Start the API: `npm run dev:server` (API runs at `http://localhost:4000`).
6. In another terminal start the frontend: `npm run dev`.
7. Open the local URL printed by Vite.

Never commit `.env` or real database credentials. `.env.example` is safe to commit.

## REST API overview
Base URL: `http://localhost:4000/api`

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | API/database health |
| GET | `/dashboard` | Dashboard summary |
| GET/POST | `/suppliers` | List/create suppliers |
| GET/PUT/DELETE | `/suppliers/:id` | Read/update/delete supplier |
| GET/POST | `/vendors` | List/create vendors |
| GET/PUT/DELETE | `/vendors/:id` | Read/update/delete vendor |
| GET | `/vendors/search?q=` | Search vendors by name/phone |
| GET/POST | `/fruits` | List/create fruits |
| PUT | `/fruits/:id` | Update fruit |
| GET | `/stock` | Stock by fruit and packaging size |
| GET | `/stock/low?threshold=10` | Low-stock report |
| POST | `/purchases` | Record multi-item purchase |
| POST | `/sales` | Record multi-item sale |
| POST | `/sales/:id/payments` | Record a payment against a sale |
| GET | `/vendors/balances` | Vendor outstanding balances |
| GET | `/reports/top-fruits` | Five most frequently sold fruits |
| GET | `/reports/revenue?from=YYYY-MM-DD&to=YYYY-MM-DD` | Revenue in date range |
| GET | `/reports/top-vendor` | Vendor with most boxes purchased |

### Example purchase request
```json
{
  "supplier_id": 1,
  "items": [
    { "fruit_id": 1, "quantity": 20, "unit_cost": 85, "packaging_size": "SMALL" },
    { "fruit_id": 2, "quantity": 10, "unit_cost": 120, "packaging_size": "LARGE" }
  ]
}
```

### Example sale request
```json
{
  "vendor_id": 1,
  "payment_method": "CREDIT",
  "amount_paid": 100,
  "items": [
    { "fruit_id": 1, "quantity": 3, "unit_price": 150, "packaging_size": "SMALL" },
    { "fruit_id": 2, "quantity": 2, "unit_price": 230, "packaging_size": "LARGE" }
  ]
}
```

The sale API checks every requested item inside a MySQL transaction before committing. If any item has insufficient stock, it rolls back the transaction and does not leave partial sale or stock records.

## Important submission checklist
- Add realistic sample supplier, vendor, purchase and sales records for your demonstration.
- Configure and test the MySQL connection on your own computer.
- Test all API endpoints and capture screenshots/Postman evidence.
- Add your own recorded demonstration video and deployed live link/GitHub repository link.
- Review and understand the code so you can explain the database relationships, transactions, SQL reports and payment calculations during assessment.

## Google Maps integration

The dashboard now includes a **Map** workspace with an embedded Google Map, a location search field, quick links to Maseru and the South African supplier provinces listed in the assignment, and an **Open in Google Maps** link. This basic embed uses Google Maps search/embed URLs and does not require an API key. It is suitable for viewing/searching locations; it does not yet plot live supplier/vendor database records as pins. To add those live pins, store each supplier/vendor's full address or latitude/longitude and connect those records to a Google Maps JavaScript API map. A production Maps JavaScript API integration may require a Google Cloud project, billing, an enabled Maps JavaScript API, and a restricted browser API key.


## Google Maps: supplier and vendor pins

The Map workspace reads saved suppliers and vendors from `GET /api/locations`. Supplier pins use `address` and `province`; vendor pins use `location` and Lesotho. For precise pins, set `latitude` and `longitude` on each record (decimal degrees). The API accepts these optional fields on supplier/vendor create and update requests.

To enable the interactive multi-pin Google Map, create a Google Maps Platform API key, enable **Maps JavaScript API** and **Geocoding API**, and set `VITE_GOOGLE_MAPS_API_KEY` in the frontend `.env` file. Restrict the key to your website origins and only the APIs used. Restart the frontend after changing `.env`. If no key is configured, the page falls back to a standard Google Maps embed and still lists saved businesses with direct Google Maps links.

For an existing database, run `database/migrations/2026-11-21-add-map-coordinates.sql` once. For a fresh database, the columns are included in `database/schema.sql`.
