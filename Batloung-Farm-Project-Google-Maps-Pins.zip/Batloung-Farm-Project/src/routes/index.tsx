import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Activity, ArrowDownRight, ArrowUpRight, Bell, Boxes, ChartNoAxesCombined, ChevronDown, CircleDollarSign, ClipboardList, Command, CreditCard, Download, Leaf, Menu, MapPinned, Package, Plus, Search, Settings, ShoppingBag, ShoppingCart, Truck, Users, Warehouse } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Batloung Farm | Distribution Management" }, { name: "description", content: "Fresh produce distribution management system" }] }),
  component: Dashboard,
});

type DashboardData = { todayRevenue: number; todaySales: number; vendors: number; suppliers: number; lowStock: { fruit_name: string; packaging_size: string; available_quantity: number }[]; recentSales: { sale_id: number; sale_date: string; vendor_name: string; total_amount: number; payment_status: string }[] };
const demo: DashboardData = { todayRevenue: 12850, todaySales: 18, vendors: 42, suppliers: 12, lowStock: [{ fruit_name: "Mangoes", packaging_size: "LARGE", available_quantity: 4 }, { fruit_name: "Grapes", packaging_size: "MEDIUM", available_quantity: 7 }, { fruit_name: "Apples", packaging_size: "SMALL", available_quantity: 9 }], recentSales: [{ sale_id: 1048, sale_date: new Date().toISOString(), vendor_name: "Maseru Fresh Market", total_amount: 2450, payment_status: "PAID" }, { sale_id: 1047, sale_date: new Date().toISOString(), vendor_name: "Thaba-Bosiu Traders", total_amount: 1800, payment_status: "PARTIALLY_PAID" }, { sale_id: 1046, sale_date: new Date().toISOString(), vendor_name: "City Street Vendors", total_amount: 3200, payment_status: "UNPAID" }, { sale_id: 1045, sale_date: new Date().toISOString(), vendor_name: "Pioneer Retail", total_amount: 1450, payment_status: "PAID" }] };
const nav = [{ label: "Overview", icon: ChartNoAxesCombined }, { label: "Inventory", icon: Boxes }, { label: "Sales", icon: ShoppingCart }, { label: "Purchases", icon: ShoppingBag }, { label: "Vendors", icon: Users }, { label: "Suppliers", icon: Truck }, { label: "Payments", icon: CreditCard }, { label: "Reports", icon: ClipboardList }, { label: "Map", icon: MapPinned }];
const money = (n: number) => `M ${Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
function Dashboard() {
  const [active, setActive] = useState("Overview"); const [data, setData] = useState<DashboardData>(demo); const [connected, setConnected] = useState(false); const [query, setQuery] = useState(""); const [mobileOpen, setMobileOpen] = useState(false);
  useEffect(() => { fetch(`${import.meta.env.VITE_API_URL || "http://localhost:4000"}/api/dashboard`).then(r => { if (!r.ok) throw new Error(); return r.json(); }).then(r => { if (r.success) { setData(r.data); setConnected(true); } }).catch(() => setConnected(false)); }, []);
  const stats = [{ label: "Today's revenue", value: money(data.todayRevenue), change: "+12.8%", icon: CircleDollarSign, tone: "green" }, { label: "Sales today", value: String(data.todaySales), change: "+8.2%", icon: ShoppingCart, tone: "blue" }, { label: "Registered vendors", value: String(data.vendors), change: "+4 this month", icon: Users, tone: "orange" }, { label: "Active suppliers", value: String(data.suppliers), change: "Across 8 provinces", icon: Truck, tone: "purple" }];
  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}><div className="brand"><div className="brand-mark"><Leaf size={23}/></div><div><strong>batloung<span>.</span></strong><small>FARM DISTRIBUTION</small></div></div><div className="workspace"><span className="workspace-avatar">BF</span><div><b>Batloung Farm</b><small>Administrator workspace</small></div><ChevronDown size={15}/></div><div className="nav-caption">WORKSPACE</div><nav>{nav.map(item => <button key={item.label} onClick={() => { setActive(item.label); setMobileOpen(false); }} className={`nav-link ${active === item.label ? "active" : ""}`}><item.icon size={18}/><span>{item.label}</span>{item.label === "Inventory" && <i className="nav-dot"/>}</button>)}</nav><div className="sidebar-bottom"><div className="help-card"><div className="help-icon"><Activity size={17}/></div><b>Need a hand?</b><p>Get help managing your distribution operations.</p><button onClick={() => setActive("Help")}>Visit help centre <span>↗</span></button></div><button className="nav-link"><Settings size={18}/>Settings</button><div className="profile"><div className="profile-avatar">BM</div><div><b>Farm Administrator</b><small>admin@batloungfarm.co.ls</small></div><ChevronDown size={15}/></div></div></aside>
    <main className="main-area"><header className="topbar"><button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{active}</b></div><div className="top-actions"><div className="searchbox"><Search size={16}/><input placeholder="Search anything..." value={query} onChange={e => setQuery(e.target.value)}/><kbd>⌘ K</kbd></div><button className="icon-button" aria-label="Notifications"><Bell size={19}/><i/></button><div className="top-avatar">BM</div></div></header>
      <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><span className="live-dot"/> FARM OPERATIONS <span className="date-sep">/</span> MASERU, LESOTHO</div><h1>{active === "Overview" ? "Good morning, Administrator" : active}</h1><p>{active === "Overview" ? "Here's what's happening across your distribution business today." : `Manage your ${active.toLowerCase()} and keep your operations moving.`}</p></div><div className="welcome-actions"><span className={`connection ${connected ? "online" : "offline"}`}><i/>{connected ? "Live data connected" : "Preview data"}</span><button className="primary-btn" onClick={() => setActive("Sales")}><Plus size={17}/> New transaction</button></div></div>
      {active === "Map" ? <MapWorkspace /> : active === "Overview" ? <><section className="stats-grid">{stats.map((s,i)=><div className="stat-card" key={s.label}><div className="stat-top"><span>{s.label}</span><div className={`stat-icon ${s.tone}`}><s.icon size={19}/></div></div><strong>{s.value}</strong><div className="stat-foot"><span className="trend"><ArrowUpRight size={14}/>{s.change}</span><span>vs last period</span></div></div>)}</section>
      <section className="content-grid"><div className="panel performance-panel"><div className="panel-head"><div><h2>Sales performance</h2><p>Revenue overview across your business</p></div><button className="select-button">This week <ChevronDown size={14}/></button></div><div className="chart-summary"><strong>{money(data.todayRevenue)}</strong><span className="trend"><ArrowUpRight size={14}/> 12.8%</span><small>Total revenue today</small></div><div className="chart-area"><div className="chart-y"><span>M 15k</span><span>M 10k</span><span>M 5k</span><span>M 0</span></div><div className="chart"><div className="chart-grid"><i/><i/><i/><i/></div><svg viewBox="0 0 650 190" preserveAspectRatio="none" role="img" aria-label="Illustrative weekly revenue chart"><defs><linearGradient id="fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#25845b" stopOpacity=".2"/><stop offset="100%" stopColor="#25845b" stopOpacity="0"/></linearGradient></defs><path d="M0 145 C35 132 55 150 92 115 S145 130 185 90 S245 120 280 82 S340 94 372 65 S430 86 465 52 S520 78 555 34 S610 48 650 18 L650 190 L0 190Z" fill="url(#fill)"/><path d="M0 145 C35 132 55 150 92 115 S145 130 185 90 S245 120 280 82 S340 94 372 65 S430 86 465 52 S520 78 555 34 S610 48 650 18" fill="none" stroke="#25845b" strokeWidth="3" strokeLinecap="round"/></svg><div className="chart-x"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></div></div><div className="chart-note"><span><i className="legend-dot"/> Sales revenue</span><span>Illustrative trend · Connect API for live reporting</span></div></div>
      <div className="panel stock-panel"><div className="panel-head"><div><h2>Low stock alerts</h2><p>Items that need your attention</p></div><button className="text-action" onClick={()=>setActive("Inventory")}>View inventory <ArrowUpRight size={14}/></button></div><div className="stock-list">{data.lowStock.length ? data.lowStock.map((item,i)=><div className="stock-item" key={`${item.fruit_name}-${item.packaging_size}`}><div className={`fruit-thumb fruit-${i%3}`}>{item.fruit_name[0]}</div><div className="stock-name"><b>{item.fruit_name}</b><small>{item.packaging_size.toLowerCase()} boxes</small></div><div className="stock-qty"><b>{item.available_quantity}</b><small>left</small></div><span className="warning-pill">Low stock</span></div>) : <div className="empty-state">No low-stock items. Great work!</div>}</div><button className="outline-btn full-btn" onClick={()=>setActive("Inventory")}>Manage stock <ArrowUpRight size={15}/></button></div></section>
      <section className="panel transactions-panel"><div className="panel-head"><div><h2>Recent transactions</h2><p>Keep track of your latest sales activity</p></div><button className="text-action" onClick={()=>setActive("Sales")}>View all transactions <ArrowUpRight size={14}/></button></div><div className="table-wrap"><table><thead><tr><th>TRANSACTION</th><th>VENDOR</th><th>DATE</th><th>AMOUNT</th><th>PAYMENT STATUS</th><th/></tr></thead><tbody>{data.recentSales.map(s=><tr key={s.sale_id}><td><b className="transaction-id">#SL-{s.sale_id}</b></td><td><div className="vendor-cell"><span>{s.vendor_name.slice(0,1)}</span>{s.vendor_name}</div></td><td>{new Date(s.sale_date).toLocaleDateString()}</td><td><b>{money(s.total_amount)}</b></td><td><span className={`status ${s.payment_status.toLowerCase()}`}>{s.payment_status.replace("_"," ")}</span></td><td><button className="more-button">···</button></td></tr>)}</tbody></table></div></section></> : <section className="panel module-panel"><div className="module-icon"><Package size={26}/></div><h2>{active} management</h2><p>Your {active.toLowerCase()} workspace is ready. Connect the API and use the documented endpoints to manage live records.</p><div className="module-actions"><button className="primary-btn" onClick={()=>setActive("Overview")}>Back to overview</button><a href="http://localhost:4000/api/health" target="_blank" rel="noreferrer" className="outline-btn">Check API connection ↗</a></div><div className="module-hint"><b>API setup</b><code>npm run dev:server</code><span>Configure your MySQL database using the included .env.example and database/schema.sql files.</span></div></section>}
      <footer className="footer"><span>© 2026 Batloung Farm Distribution. All rights reserved.</span><span><i className="footer-leaf"><Leaf size={13}/></i> Growing connections, delivering freshness.</span></footer></div></main></div>;
}


type MapBusiness = { id: number; name: string; type: "SUPPLIER" | "VENDOR"; address: string; latitude: number | string | null; longitude: number | string | null; region: string };

declare global { interface Window { google?: any; __batloungGoogleMapsLoading?: Promise<void> } }

function loadGoogleMaps(apiKey: string) {
  if (window.google?.maps) return Promise.resolve();
  if (window.__batloungGoogleMapsLoading) return window.__batloungGoogleMapsLoading;
  window.__batloungGoogleMapsLoading = new Promise<void>((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>("script[data-batloung-google-maps]");
    if (existing) { existing.addEventListener("load", () => resolve(), { once: true }); existing.addEventListener("error", () => reject(new Error("Google Maps could not load")), { once: true }); return; }
    const script = document.createElement("script");
    script.dataset.batloungGoogleMaps = "true";
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(apiKey)}&v=weekly`;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Google Maps could not load. Check the API key and enabled APIs."));
    document.head.appendChild(script);
  });
  return window.__batloungGoogleMapsLoading;
}

function MapWorkspace() {
  const [locations, setLocations] = useState<MapBusiness[]>([]);
  const [place, setPlace] = useState("Maseru, Lesotho");
  const [draft, setDraft] = useState("Maseru, Lesotho");
  const [filter, setFilter] = useState<"ALL" | "SUPPLIER" | "VENDOR">("ALL");
  const [mapError, setMapError] = useState("");
  const mapElement = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<any>(null);
  const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string | undefined;
  const mapUrl = `https://www.google.com/maps?q=${encodeURIComponent(place)}&output=embed`;
  const openUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place)}`;
  const visibleLocations = locations.filter(item => filter === "ALL" || item.type === filter);

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL || "http://localhost:4000"}/api/locations`)
      .then(response => { if (!response.ok) throw new Error("Could not load saved business locations"); return response.json(); })
      .then(result => setLocations(result.data || []))
      .catch(() => setLocations([]));
  }, []);

  useEffect(() => {
    if (!apiKey || !mapElement.current) return;
    let cancelled = false;
    loadGoogleMaps(apiKey).then(() => {
      if (cancelled || !mapElement.current) return;
      const google = window.google;
      const map = new google.maps.Map(mapElement.current, { center: { lat: -29.31, lng: 27.48 }, zoom: 7, mapTypeControl: true, streetViewControl: false, fullscreenControl: true });
      mapInstance.current = map;
      const bounds = new google.maps.LatLngBounds();
      const info = new google.maps.InfoWindow();
      const geocoder = new google.maps.Geocoder();
      let plotted = 0;
      const addMarker = (item: MapBusiness, position: { lat: number; lng: number }) => {
        const marker = new google.maps.Marker({ map, position, title: item.name, label: item.type === "SUPPLIER" ? "S" : "V" });
        marker.addListener("click", () => {
          info.setContent(`<div style="padding:4px 8px;max-width:240px"><strong>${item.name.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c] || c))}</strong><br><span>${item.type === "SUPPLIER" ? "Supplier" : "Vendor"}</span><br>${item.address}</div>`);
          info.open({ map, anchor: marker });
        });
        bounds.extend(position); plotted += 1;
      };
      const targets = visibleLocations;
      Promise.all(targets.map(async item => {
        if (item.latitude !== null && item.longitude !== null && Number.isFinite(Number(item.latitude)) && Number.isFinite(Number(item.longitude))) {
          addMarker(item, { lat: Number(item.latitude), lng: Number(item.longitude) }); return;
        }
        const address = [item.address, item.region].filter(Boolean).join(", ");
        if (!address.trim()) return;
        try { const result = await geocoder.geocode({ address }); if (!cancelled && result.results[0]) { const point = result.results[0].geometry.location; addMarker(item, { lat: point.lat(), lng: point.lng() }); } }
        catch { /* An unrecognised address remains visible in the location list below. */ }
      })).then(() => { if (cancelled) return; if (plotted) { map.fitBounds(bounds); if (plotted === 1) map.setZoom(11); } });
    }).catch(error => { if (!cancelled) setMapError(error.message || "Google Maps failed to load"); });
    return () => { cancelled = true; };
  }, [apiKey, locations, filter]);

  const quickPlaces = ["Maseru, Lesotho", "Gauteng, South Africa", "Free State, South Africa", "KwaZulu-Natal, South Africa", "Western Cape, South Africa", "Eastern Cape, South Africa", "Limpopo, South Africa", "Mpumalanga, South Africa", "North West, South Africa"];
  return <section className="map-workspace">
    <div className="panel map-panel">
      <div className="panel-head"><div><h2>Google Maps · Business locations</h2><p>Supplier and vendor locations saved in your Batloung Farm records</p></div><a className="outline-btn map-open" href={openUrl} target="_blank" rel="noreferrer">Open in Google Maps ↗</a></div>
      <form className="map-search" onSubmit={e => { e.preventDefault(); if (draft.trim()) { setPlace(draft.trim()); window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(draft.trim())}`, "_blank", "noopener,noreferrer"); } }}>
        <MapPinned size={18}/><input aria-label="Search map location" value={draft} onChange={e => setDraft(e.target.value)} placeholder="Search a town, address or province..."/><button className="primary-btn" type="submit">Search Google Maps</button>
      </form>
      <div className="map-filter-row"><div className="map-filters">{(["ALL", "SUPPLIER", "VENDOR"] as const).map(value => <button type="button" key={value} className={filter === value ? "map-chip selected" : "map-chip"} onClick={() => setFilter(value)}>{value === "ALL" ? "All locations" : value === "SUPPLIER" ? "Suppliers" : "Vendors"}</button>)}</div><span className="map-count">{visibleLocations.length} saved location{visibleLocations.length === 1 ? "" : "s"}</span></div>
      {apiKey ? <div ref={mapElement} className="google-map-frame" aria-label="Google map with supplier and vendor pins"/> : <div className="google-map-frame"><iframe title={`Google Map showing ${place}`} src={mapUrl} loading="lazy" referrerPolicy="no-referrer-when-downgrade" allowFullScreen /></div>}
      {mapError && <div className="map-note"><MapPinned size={17}/><span>{mapError}. The address search and location list are still available.</span></div>}
      <div className="map-location-block"><div><h3>Saved suppliers and vendors</h3><p>Map pins use saved latitude/longitude when available, otherwise Google Maps geocodes the saved address.</p></div>
        {visibleLocations.length ? <div className="map-record-list">{visibleLocations.map(item => <div className="map-record" key={`${item.type}-${item.id}`}><span className={`map-record-icon ${item.type.toLowerCase()}`}>{item.type === "SUPPLIER" ? "S" : "V"}</span><div className="map-record-info"><b>{item.name}</b><small>{item.type} · {item.address}{item.region ? `, ${item.region}` : ""}</small></div><a href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([item.address,item.region].filter(Boolean).join(", "))}`} target="_blank" rel="noreferrer">Directions ↗</a></div>)}</div> : <div className="map-empty">No supplier or vendor records returned yet. Add business records with a complete address to see them here.</div>}
      </div>
      <div className="map-location-block"><div><h3>Supplier regions</h3><p>Quickly open the main operating regions.</p></div><div className="map-chips">{quickPlaces.map(item => <button key={item} className={place === item ? "map-chip selected" : "map-chip"} onClick={() => { setPlace(item); setDraft(item); }} type="button">{item}</button>)}</div></div>
      <div className="map-note"><MapPinned size={17}/><span>{apiKey ? "Google Maps JavaScript API is enabled. Add coordinates to supplier/vendor records for the most accurate pins; address geocoding is used as a fallback." : "For interactive multiple pins, add VITE_GOOGLE_MAPS_API_KEY to .env and enable Maps JavaScript API and Geocoding API in Google Cloud. Without a key, the map uses the standard Google Maps embed and the saved location directory."}</span></div>
    </div>
  </section>;
}
