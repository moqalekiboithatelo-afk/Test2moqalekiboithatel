# Batloung Farm project source

This is an export of the currently saved project, not a completed assignment.

## Current state
The home page is the original starter screen. The saved source does not contain the farm dashboard, supplier/vendor management, purchases, sales, stock reports, or a Google Maps page. Cloud and connector configuration is managed separately by Lovable and is not included here.

## Required assignment technologies
This source uses TanStack Start, React, TypeScript and Tailwind CSS. It is not the MySQL / Node.js / Express implementation specified by the assignment.

## Run locally
Install Bun, then run `bun install` and `bun run dev` from this folder. The farm functionality still needs to be implemented.

Credentials, repository metadata, installed dependencies and generated build output are intentionally excluded. No business data or user accounts are exported. Configure your own environment securely before adding any connected features.
