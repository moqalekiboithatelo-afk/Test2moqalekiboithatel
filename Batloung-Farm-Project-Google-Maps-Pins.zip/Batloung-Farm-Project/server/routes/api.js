import { Router } from 'express';
import pool from '../config/db.js';
import { asyncHandler } from '../middleware/errors.js';
const router = Router();
const sizes = ['SMALL','MEDIUM','LARGE'];
const provinces = ['Gauteng','Free State','KwaZulu-Natal','Western Cape','Eastern Cape','Limpopo','Mpumalanga','North West'];
const fail = (message, status=400) => Object.assign(new Error(message), {status});
const rows = async (sql, values=[]) => (await pool.execute(sql, values))[0];
const validId = (id) => Number.isInteger(Number(id)) && Number(id) > 0;

router.get('/health', asyncHandler(async (req,res) => { await pool.query('SELECT 1'); res.json({success:true,message:'Batloung Farm API is healthy'}); }));
router.get('/dashboard', asyncHandler(async (req,res) => {
 const [[sales]] = await pool.query("SELECT COALESCE(SUM(total_amount),0) revenue, COUNT(*) sales_count FROM sales WHERE DATE(sale_date)=CURDATE()");
 const [[vendors]] = await pool.query('SELECT COUNT(*) count FROM vendors');
 const [[suppliers]] = await pool.query('SELECT COUNT(*) count FROM suppliers');
 const [lowStock] = await pool.query("SELECT f.fruit_name,s.packaging_size,s.available_quantity FROM stock s JOIN fruits f ON f.fruit_id=s.fruit_id WHERE s.available_quantity <= 10 ORDER BY s.available_quantity ASC LIMIT 8");
 const [recentSales] = await pool.query('SELECT s.sale_id,s.sale_date,v.vendor_name,s.total_amount,s.payment_status FROM sales s JOIN vendors v ON v.vendor_id=s.vendor_id ORDER BY s.sale_date DESC LIMIT 6');
 res.json({success:true,data:{todayRevenue:sales.revenue,todaySales:sales.sales_count,vendors:vendors.count,suppliers:suppliers.count,lowStock,recentSales}});
}));

function crud(path, table, id, fields, required=fields) {
 router.get(`/${path}`, asyncHandler(async(req,res)=>{ const data=await rows(`SELECT * FROM ${table} ORDER BY ${id} DESC`); res.json({success:true,data}); }));
 router.get(`/${path}/:id`, asyncHandler(async(req,res)=>{ const data=await rows(`SELECT * FROM ${table} WHERE ${id}=?`,[req.params.id]); if(!data.length) throw fail('Record not found',404); res.json({success:true,data:data[0]}); }));
 router.post(`/${path}`, asyncHandler(async(req,res)=>{ for(const f of required) if(req.body[f]===undefined || req.body[f]==='') throw fail(`${f} is required`); const vals=fields.map(f=>req.body[f]??null); const [r]=await pool.execute(`INSERT INTO ${table} (${fields.join(',')}) VALUES (${fields.map(()=>'?').join(',')})`,vals); res.status(201).json({success:true,message:'Record created',id:r.insertId}); }));
 router.put(`/${path}/:id`, asyncHandler(async(req,res)=>{ if(!validId(req.params.id)) throw fail('Invalid record ID'); const sets=fields.filter(f=>req.body[f]!==undefined); if(!sets.length) throw fail('Provide at least one field to update'); const vals=sets.map(f=>req.body[f]); const [r]=await pool.execute(`UPDATE ${table} SET ${sets.map(f=>`${f}=?`).join(',')} WHERE ${id}=?`,[...vals,req.params.id]); if(!r.affectedRows) throw fail('Record not found',404); res.json({success:true,message:'Record updated'}); }));
 router.delete(`/${path}/:id`, asyncHandler(async(req,res)=>{ const [r]=await pool.execute(`DELETE FROM ${table} WHERE ${id}=?`,[req.params.id]); if(!r.affectedRows) throw fail('Record not found',404); res.json({success:true,message:'Record deleted'}); }));
}
crud('suppliers','suppliers','supplier_id',['business_name','contact_person','phone','province','address','latitude','longitude']);
// One normalized feed for the map. Coordinates are optional; the UI geocodes saved addresses when possible.
router.get('/locations', asyncHandler(async(req,res)=>{
 const [suppliers] = await pool.query("SELECT supplier_id AS id, business_name AS name, 'SUPPLIER' AS type, address AS address, latitude, longitude, province AS region FROM suppliers ORDER BY business_name");
 const [vendors] = await pool.query("SELECT vendor_id AS id, vendor_name AS name, 'VENDOR' AS type, location AS address, latitude, longitude, 'Lesotho' AS region FROM vendors ORDER BY vendor_name");
 res.json({success:true,data:[...suppliers,...vendors]});
}));

router.get('/vendors/search', asyncHandler(async(req,res)=>{ const q=`%${req.query.q||''}%`; const data=await rows('SELECT * FROM vendors WHERE vendor_name LIKE ? OR phone_number LIKE ? ORDER BY vendor_name',[q,q]); res.json({success:true,data}); }));
router.get('/vendors/balances', asyncHandler(async(req,res)=>{const data=await rows("SELECT v.vendor_id,v.vendor_name,COALESCE(SUM(s.total_amount),0) total_sales,COALESCE(SUM(s.amount_paid),0) total_paid,COALESCE(SUM(s.total_amount-s.amount_paid),0) outstanding_balance FROM vendors v LEFT JOIN sales s ON s.vendor_id=v.vendor_id GROUP BY v.vendor_id,v.vendor_name ORDER BY outstanding_balance DESC");res.json({success:true,data});}));
crud('vendors','vendors','vendor_id',['vendor_name','phone_number','location','latitude','longitude']);
router.get('/fruits', asyncHandler(async(req,res)=>{res.json({success:true,data:await rows('SELECT * FROM fruits ORDER BY fruit_name')});}));
router.post('/fruits', asyncHandler(async(req,res)=>{const {fruit_name,description=''}=req.body;if(!fruit_name)throw fail('fruit_name is required');const [r]=await pool.execute('INSERT INTO fruits(fruit_name,description) VALUES(?,?)',[fruit_name,description]);for(const size of sizes)await pool.execute('INSERT INTO stock(fruit_id,packaging_size,available_quantity) VALUES(?,?,0)',[r.insertId,size]);res.status(201).json({success:true,id:r.insertId});}));
router.put('/fruits/:id', asyncHandler(async(req,res)=>{const {fruit_name,description,status}=req.body;const [r]=await pool.execute('UPDATE fruits SET fruit_name=COALESCE(?,fruit_name),description=COALESCE(?,description),status=COALESCE(?,status) WHERE fruit_id=?',[fruit_name??null,description??null,status??null,req.params.id]);if(!r.affectedRows)throw fail('Fruit not found',404);res.json({success:true,message:'Fruit updated'});}));
router.get('/stock', asyncHandler(async(req,res)=>{const data=await rows('SELECT f.fruit_id,f.fruit_name,s.packaging_size,s.available_quantity FROM stock s JOIN fruits f ON f.fruit_id=s.fruit_id ORDER BY f.fruit_name, FIELD(s.packaging_size,\'SMALL\',\'MEDIUM\',\'LARGE\')');res.json({success:true,data});}));
router.get('/stock/low', asyncHandler(async(req,res)=>{const threshold=Math.max(0,Number(req.query.threshold??10));const data=await rows('SELECT f.fruit_name,s.packaging_size,s.available_quantity FROM stock s JOIN fruits f ON f.fruit_id=s.fruit_id WHERE s.available_quantity<=? ORDER BY s.available_quantity',[threshold]);res.json({success:true,data});}));

router.post('/purchases', asyncHandler(async(req,res)=>{
 const {supplier_id,items}=req.body;if(!validId(supplier_id)||!Array.isArray(items)||!items.length)throw fail('A valid supplier and at least one item are required');
 const c=await pool.getConnection();try{await c.beginTransaction();let total=0;const normalized=[];
 for(const item of items){const q=Number(item.quantity),cost=Number(item.unit_cost),fruit=Number(item.fruit_id),size=String(item.packaging_size||'').toUpperCase();if(!validId(fruit)||!Number.isInteger(q)||q<=0||!Number.isFinite(cost)||cost<0||!sizes.includes(size))throw fail('Invalid purchase item');total+=q*cost;normalized.push({fruit,q,cost,size});}
 const [p]=await c.execute('INSERT INTO purchases(supplier_id,total_amount) VALUES(?,?)',[supplier_id,total]);
 for(const i of normalized){await c.execute('INSERT INTO purchase_details(purchase_id,fruit_id,quantity,unit_cost,packaging_size) VALUES(?,?,?,?,?)',[p.insertId,i.fruit,i.q,i.cost,i.size]);await c.execute('INSERT INTO stock(fruit_id,packaging_size,available_quantity) VALUES(?,?,?) ON DUPLICATE KEY UPDATE available_quantity=available_quantity+VALUES(available_quantity)',[i.fruit,i.size,i.q]);}
 await c.commit();res.status(201).json({success:true,purchase_id:p.insertId,total_amount:total});}catch(e){await c.rollback();throw e;}finally{c.release();}
}));
router.post('/sales', asyncHandler(async(req,res)=>{
 const {vendor_id,items,payment_method='CASH',amount_paid}=req.body;if(!validId(vendor_id)||!Array.isArray(items)||!items.length)throw fail('A valid vendor and at least one item are required');
 if(!['CASH','MOBILE_MONEY','CREDIT'].includes(payment_method))throw fail('Invalid payment method');
 const c=await pool.getConnection();try{await c.beginTransaction();let total=0;const normalized=[];
 for(const item of items){const q=Number(item.quantity),price=Number(item.unit_price),fruit=Number(item.fruit_id),size=String(item.packaging_size||'').toUpperCase();if(!validId(fruit)||!Number.isInteger(q)||q<=0||!Number.isFinite(price)||price<0||!sizes.includes(size))throw fail('Invalid sale item');const [stockRows]=await c.execute('SELECT available_quantity FROM stock WHERE fruit_id=? AND packaging_size=? FOR UPDATE',[fruit,size]);if(!stockRows.length||stockRows[0].available_quantity<q)throw fail(`Insufficient ${size.toLowerCase()} stock for fruit ID ${fruit}`);total+=q*price;normalized.push({fruit,q,price,size});}
 const paid=amount_paid===undefined?(payment_method==='CREDIT'?0:total):Number(amount_paid);if(!Number.isFinite(paid)||paid<0||paid>total)throw fail('Amount paid must be between zero and the sale total');const status=paid===0?'UNPAID':paid===total?'PAID':'PARTIALLY_PAID';
 const [s]=await c.execute('INSERT INTO sales(vendor_id,payment_method,payment_status,total_amount,amount_paid) VALUES(?,?,?,?,?)',[vendor_id,payment_method,status,total,paid]);
 for(const i of normalized){await c.execute('INSERT INTO sales_details(sale_id,fruit_id,packaging_size,quantity,unit_price) VALUES(?,?,?,?,?)',[s.insertId,i.fruit,i.size,i.q,i.price]);const [u]=await c.execute('UPDATE stock SET available_quantity=available_quantity-? WHERE fruit_id=? AND packaging_size=? AND available_quantity>=?',[i.q,i.fruit,i.size,i.q]);if(!u.affectedRows)throw fail('Stock changed during sale; transaction cancelled',409);}
 if(paid>0)await c.execute('INSERT INTO payments(sale_id,payment_method,amount) VALUES(?,?,?)',[s.insertId,payment_method,paid]);await c.commit();res.status(201).json({success:true,sale_id:s.insertId,total_amount:total,amount_paid:paid,outstanding_balance:total-paid,payment_status:status});
 }catch(e){await c.rollback();throw e;}finally{c.release();}
}));
router.post('/sales/:id/payments', asyncHandler(async(req,res)=>{const amount=Number(req.body.amount),method=req.body.payment_method;if(!Number.isFinite(amount)||amount<=0||!['CASH','MOBILE_MONEY'].includes(method))throw fail('A positive payment and valid payment method are required');const c=await pool.getConnection();try{await c.beginTransaction();const [[sale]]=await c.execute('SELECT * FROM sales WHERE sale_id=? FOR UPDATE',[req.params.id]);if(!sale)throw fail('Sale not found',404);if(amount>sale.total_amount-sale.amount_paid)throw fail('Payment exceeds outstanding balance');const paid=sale.amount_paid+amount,status=paid===sale.total_amount?'PAID':'PARTIALLY_PAID';await c.execute('INSERT INTO payments(sale_id,payment_method,amount) VALUES(?,?,?)',[req.params.id,method,amount]);await c.execute('UPDATE sales SET amount_paid=?,payment_status=? WHERE sale_id=?',[paid,status,req.params.id]);await c.commit();res.json({success:true,amount_paid:paid,outstanding_balance:sale.total_amount-paid,payment_status:status});}catch(e){await c.rollback();throw e;}finally{c.release();}}));
router.get('/reports/top-fruits', asyncHandler(async(req,res)=>{const data=await rows('SELECT f.fruit_name,SUM(sd.quantity) boxes_sold FROM sales_details sd JOIN fruits f ON f.fruit_id=sd.fruit_id GROUP BY f.fruit_id,f.fruit_name ORDER BY boxes_sold DESC LIMIT 5');res.json({success:true,data});}));
router.get('/reports/revenue', asyncHandler(async(req,res)=>{const from=req.query.from||'2000-01-01',to=req.query.to||'2099-12-31';const data=await rows('SELECT COALESCE(SUM(total_amount),0) revenue,COUNT(*) sales_count FROM sales WHERE DATE(sale_date) BETWEEN ? AND ?',[from,to]);res.json({success:true,data:data[0]});}));
router.get('/reports/top-vendor', asyncHandler(async(req,res)=>{const data=await rows('SELECT v.vendor_id,v.vendor_name,SUM(sd.quantity) boxes_purchased FROM sales s JOIN vendors v ON v.vendor_id=s.vendor_id JOIN sales_details sd ON sd.sale_id=s.sale_id GROUP BY v.vendor_id,v.vendor_name ORDER BY boxes_purchased DESC LIMIT 1');res.json({success:true,data:data[0]||null});}));
export default router;
