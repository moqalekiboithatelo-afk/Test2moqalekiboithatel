CREATE DATABASE IF NOT EXISTS batloung_farm;
USE batloung_farm;

CREATE TABLE IF NOT EXISTS suppliers (
  supplier_id INT AUTO_INCREMENT PRIMARY KEY,
  business_name VARCHAR(140) NOT NULL,
  contact_person VARCHAR(120) NOT NULL,
  phone VARCHAR(30) NOT NULL UNIQUE,
  province ENUM('Gauteng','Free State','KwaZulu-Natal','Western Cape','Eastern Cape','Limpopo','Mpumalanga','North West') NOT NULL,
  address VARCHAR(255) NOT NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS fruits (
  fruit_id INT AUTO_INCREMENT PRIMARY KEY,
  fruit_name ENUM('Apples','Bananas','Oranges','Mangoes','Grapes') NOT NULL UNIQUE,
  description VARCHAR(255),
  status ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE'
);
CREATE TABLE IF NOT EXISTS vendors (
  vendor_id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_name VARCHAR(140) NOT NULL,
  phone_number VARCHAR(30) NOT NULL UNIQUE,
  location VARCHAR(180) NOT NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  registration_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);
CREATE TABLE IF NOT EXISTS purchases (
  purchase_id INT AUTO_INCREMENT PRIMARY KEY,
  supplier_id INT NOT NULL,
  purchase_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  CONSTRAINT fk_purchase_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);
CREATE TABLE IF NOT EXISTS purchase_details (
  purchase_detail_id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_id INT NOT NULL,
  fruit_id INT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_cost DECIMAL(10,2) NOT NULL CHECK (unit_cost >= 0),
  packaging_size ENUM('SMALL','MEDIUM','LARGE') NOT NULL,
  FOREIGN KEY (purchase_id) REFERENCES purchases(purchase_id) ON DELETE CASCADE,
  FOREIGN KEY (fruit_id) REFERENCES fruits(fruit_id)
);
CREATE TABLE IF NOT EXISTS sales (
  sale_id INT AUTO_INCREMENT PRIMARY KEY,
  vendor_id INT NOT NULL,
  sale_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  payment_method ENUM('CASH','MOBILE_MONEY','CREDIT') NOT NULL DEFAULT 'CASH',
  payment_status ENUM('PAID','PARTIALLY_PAID','UNPAID') NOT NULL DEFAULT 'UNPAID',
  total_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
  FOREIGN KEY (vendor_id) REFERENCES vendors(vendor_id)
);
CREATE TABLE IF NOT EXISTS sales_details (
  sales_detail_id INT AUTO_INCREMENT PRIMARY KEY,
  sale_id INT NOT NULL,
  fruit_id INT NOT NULL,
  packaging_size ENUM('SMALL','MEDIUM','LARGE') NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_price DECIMAL(10,2) NOT NULL CHECK (unit_price >= 0),
  FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE,
  FOREIGN KEY (fruit_id) REFERENCES fruits(fruit_id)
);
CREATE TABLE IF NOT EXISTS stock (
  stock_id INT AUTO_INCREMENT PRIMARY KEY,
  fruit_id INT NOT NULL,
  packaging_size ENUM('SMALL','MEDIUM','LARGE') NOT NULL,
  available_quantity INT NOT NULL DEFAULT 0 CHECK (available_quantity >= 0),
  UNIQUE KEY uq_fruit_packaging (fruit_id, packaging_size),
  FOREIGN KEY (fruit_id) REFERENCES fruits(fruit_id)
);
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  sale_id INT NOT NULL,
  payment_method ENUM('CASH','MOBILE_MONEY','CREDIT') NOT NULL,
  amount DECIMAL(12,2) NOT NULL CHECK (amount > 0),
  payment_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE
);

INSERT IGNORE INTO fruits (fruit_name, description) VALUES
('Apples','Fresh apples'),('Bananas','Fresh bananas'),('Oranges','Fresh oranges'),('Mangoes','Fresh mangoes'),('Grapes','Fresh grapes');
INSERT IGNORE INTO stock (fruit_id, packaging_size, available_quantity)
SELECT f.fruit_id, p.packaging_size, 0 FROM fruits f CROSS JOIN
(SELECT 'SMALL' packaging_size UNION ALL SELECT 'MEDIUM' UNION ALL SELECT 'LARGE') p;

-- Demonstration data for assessment testing (safe to re-run).
INSERT IGNORE INTO suppliers (business_name,contact_person,phone,province,address) VALUES
('Highveld Fresh Produce','Thabo Mokoena','+27 11 555 0101','Gauteng','Johannesburg, South Africa'),
('Cape Orchard Co.','Lerato Daniels','+27 21 555 0102','Western Cape','Cape Town, South Africa'),
('Free State Fruit Hub','Kabelo Maseko','+27 51 555 0103','Free State','Bloemfontein, South Africa');
INSERT IGNORE INTO vendors (vendor_name,phone_number,location) VALUES
('Maseru Fresh Market','+266 5900 1001','Maseru Central, Lesotho'),
('Thaba-Bosiu Traders','+266 5900 1002','Thaba-Bosiu, Lesotho'),
('Pioneer Retail','+266 5900 1003','Pioneer Road, Maseru, Lesotho');
UPDATE stock s JOIN fruits f ON f.fruit_id=s.fruit_id
SET s.available_quantity = CASE
 WHEN f.fruit_name='Apples' AND s.packaging_size='SMALL' THEN 36
 WHEN f.fruit_name='Apples' AND s.packaging_size='MEDIUM' THEN 24
 WHEN f.fruit_name='Apples' AND s.packaging_size='LARGE' THEN 12
 WHEN f.fruit_name='Bananas' AND s.packaging_size='SMALL' THEN 42
 WHEN f.fruit_name='Bananas' AND s.packaging_size='MEDIUM' THEN 28
 WHEN f.fruit_name='Bananas' AND s.packaging_size='LARGE' THEN 16
 WHEN f.fruit_name='Oranges' AND s.packaging_size='SMALL' THEN 30
 WHEN f.fruit_name='Oranges' AND s.packaging_size='MEDIUM' THEN 18
 WHEN f.fruit_name='Oranges' AND s.packaging_size='LARGE' THEN 11
 WHEN f.fruit_name='Mangoes' AND s.packaging_size='SMALL' THEN 22
 WHEN f.fruit_name='Mangoes' AND s.packaging_size='MEDIUM' THEN 13
 WHEN f.fruit_name='Mangoes' AND s.packaging_size='LARGE' THEN 4
 WHEN f.fruit_name='Grapes' AND s.packaging_size='SMALL' THEN 19
 WHEN f.fruit_name='Grapes' AND s.packaging_size='MEDIUM' THEN 7
 WHEN f.fruit_name='Grapes' AND s.packaging_size='LARGE' THEN 14
 ELSE s.available_quantity END;
